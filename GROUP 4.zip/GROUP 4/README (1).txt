# Student Course Registration System - README

1. Project Overview
This is a console-based Student Course Registration System written entirely in C++ without STL. It allows students to register themselves, view a list of available courses, register for courses, view all registrations, search for specific student registrations, and remove course enrollments.

The program was developed as part of the BITP1123 Data Structures & Algorithm group project, Semester 2, 2024/2025.

2. Data Structures and Algorithms Used
- Array: For storing students and courses.
- Structs: Used to define Student, Course, and Registration entities.
- Singly Linked List: Custom implementation used for handling dynamic course registration.
- Linear Search: Used to locate students by ID and courses by code.

3. Compilation & Execution
### Requirements:
- A C++ compiler 
- Visual Studio 

### Compile (Linux/Mac):
g++ Main.cpp -o registration
./registration

### Compile (Windows CMD):
g++ Main.cpp -o registration.exe
registration.exe

Or, open the .sln file in Visual Studio and press Ctrl+F5 to build and run.

4. Sample Input/Output
=== Student Course Registration System ===
1. Register Student
2. Register Course
3. View All Registrations
4. Search Student Registrations
5. Remove Course Registration
0. Exit
========================================
Enter choice: 1

Enter Student ID: B032410159
Enter Student Name: Alice
Student registered successfully.

Press Enter to continue...

5. Screenshots
The screenshots for each system feature are included in the main project report PDF, alongside their respective section descriptions.

6. Notes
- STL containers (vector, map, etc.) were not used in accordance with project guidelines.
- All memory was manually managed; linked list nodes are cleaned on exit.
- The interface is kept intentionally simple, focusing on logic and structure rather than visuals.

---

For any issues or questions, contact the project author or submit through the official UTeM channels.