#ifndef REGISTRATION_H
#define REGISTRATION_H

#include <iostream>
#include <string>

const int MAX_STUDENTS = 100;
const int MAX_COURSES = 50;
const int MAX_COURSES_PER_STUDENT = 9;

struct Student {
    std::string id;
    std::string name;
    int registeredCourses[MAX_COURSES_PER_STUDENT];
    int courseCount;
};

struct Course {
    int code;
    std::string title;
};

struct Registration {
    std::string studentId;
    int courseCode;
    Registration* next;
};

// Utility functions
void clearScreen();
void showMenu();

// Student operations
void registerStudent(Student students[], int& count);
int binarySearchStudent(Student students[], int count, const std::string& targetId);

// Course operations
void preloadCourses(Course courses[], int& count);
void showCourseList(Course courses[], int count);

// Registration operations
void registerMultipleCourses(Registration*& head, Student students[], int studentCount, Course courses[], int courseCount);
void displayRegistrations(Registration* head, Student students[], int studentCount,Course courses[], int courseCount);
void searchStudent(Registration* head, Student students[], int studentCount,Course courses[], int courseCount);
void removeRegistration(Registration*& head, Student students[], int studentCount);
void cleanup(Registration*& head);

#endif
