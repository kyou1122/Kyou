#include "registration.h"
#include <stdio.h>
#include <string>
using namespace std;

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void showMenu() {
    clearScreen();
    cout << "\n=== Student Course Registration System ===\n";
    cout << "1. Register Student\n";
    cout << "2. Register Course\n";
    cout << "3. View All Registrations\n";
    cout << "4. Search Student Registrations\n";
    cout << "5. Remove Course Registration\n";
    cout << "0. Exit\n";
    cout << "========================================\n";
    cout << "Enter choice: ";
}

int binarySearchStudent(Student students[], int count, const string& targetId) {
    int left = 0;
    int right = count - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (students[mid].id == targetId) {
            return mid;
        }

        if (students[mid].id < targetId) {
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }

    return -1;
}

void registerStudent(Student students[], int& count) {
    clearScreen();
    if (count >= MAX_STUDENTS) {
        cout << "Maximum students reached!\n";
        return;
    }

    Student newStudent;

    cout << "Enter Student ID: ";
    cin >> newStudent.id;

    cin.clear();
    while (cin.get() != '\n') continue;

    cout << "Enter Student Name: ";
    getline(cin, newStudent.name);

    newStudent.courseCount = 0;
    for (int i = 0; i < MAX_COURSES_PER_STUDENT; i++) {
        newStudent.registeredCourses[i] = -1;
    }

    int pos = count;
    while (pos > 0 && students[pos - 1].id > newStudent.id) {
        students[pos] = students[pos - 1];
        pos--;
    }
    students[pos] = newStudent;

    count++;
    cout << "\nStudent registered successfully.\n";
    cout << "Press Enter to continue...";
    cin.get();
}

void preloadCourses(Course courses[], int& count) {
    const int codes[] = { 101, 102, 103, 104, 105, 106, 107, 108, 109 };
    const string names[] = {
        "Mathematics", "HCI", "Operating Systems", "Data Structure",
        "Computer Architecture", "Co-Curricular", "English",
        "Networking", "Artificial Intelligence"
    };

    for (int i = 0; i < 9 && count < MAX_COURSES; i++) {
        courses[count].code = codes[i];
        courses[count].title = names[i];
        count++;
    }
}

void showCourseList(Course courses[], int count) {
    cout << "\nAvailable Courses:\n";
    for (int i = 0; i < count; i++) {
        cout << courses[i].code << " - " << courses[i].title << "\n";
    }
}

void registerMultipleCourses(Registration*& head, Student students[], int studentCount,
    Course courses[], int courseCount) {
    clearScreen();
    string studentId;
    cout << "Enter Student ID: ";
    cin >> studentId;

    int studentIndex = binarySearchStudent(students, studentCount, studentId);

    if (studentIndex == -1) {
        cout << "Student not found!\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    int remainingSlots = MAX_COURSES_PER_STUDENT - students[studentIndex].courseCount;
    if (remainingSlots <= 0) {
        cout << "This student has already registered the maximum number of courses ("
            << MAX_COURSES_PER_STUDENT << ").\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    showCourseList(courses, courseCount);
    cout << "\nThis student can register up to " << remainingSlots << " more courses.\n";

    int numCourses;
    cout << "How many courses to register? (1-" << remainingSlots << "): ";
    cin >> numCourses;

    if (numCourses < 1 || numCourses > remainingSlots) {
        cout << "Invalid number of courses. Must be between 1 and " << remainingSlots << ".\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    for (int i = 0; i < numCourses; i++) {
        int courseCode;
        cout << "\nEnter Course Code #" << (i + 1) << ": ";
        cin >> courseCode;

        bool courseExists = false;
        for (int j = 0; j < courseCount; j++) {
            if (courses[j].code == courseCode) {
                courseExists = true;
                break;
            }
        }

        if (!courseExists) {
            cout << "Course not found! Skipping...\n";
            continue;
        }

        bool alreadyRegistered = false;
        for (int j = 0; j < students[studentIndex].courseCount; j++) {
            if (students[studentIndex].registeredCourses[j] == courseCode) {
                alreadyRegistered = true;
                break;
            }
        }

        if (alreadyRegistered) {
            cout << "Student already registered for this course! Skipping...\n";
            continue;
        }

        Registration* newReg = new Registration{ studentId, courseCode, head };
        head = newReg;

        students[studentIndex].registeredCourses[students[studentIndex].courseCount++] = courseCode;
        cout << "Successfully registered for course: " << courseCode << "\n";
    }

    cout << "\nPress Enter to continue...";
    cin.ignore(1000, '\n');
    cin.get();
}

void displayRegistrations(Registration* head, Student students[], int studentCount,
    Course courses[], int courseCount) {
    clearScreen();
    if (!head) {
        cout << "No registrations found.\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    cout << "\n=== All Registrations ===\n";
    Registration* current = head;
    while (current) {
        string studentName = "Unknown";
        int studentIndex = binarySearchStudent(students, studentCount, current->studentId);
        if (studentIndex != -1) {
            studentName = students[studentIndex].name;
        }

        string courseName = "Unknown";
        for (int i = 0; i < courseCount; i++) {
            if (courses[i].code == current->courseCode) {
                courseName = courses[i].title;
                break;
            }
        }

        cout << "Student: " << studentName << " (" << current->studentId << ") "
            << "-> Course: " << courseName << " (" << current->courseCode << ")\n";

        current = current->next;
    }

    cout << "\nPress Enter to continue...";
    cin.ignore(1000, '\n');
    cin.get();
}

void searchStudent(Registration* head, Student students[], int studentCount,
    Course courses[], int courseCount) {
    clearScreen();
    string studentId;
    cout << "Enter Student ID to search: ";
    cin >> studentId;

    int studentIndex = binarySearchStudent(students, studentCount, studentId);

    if (studentIndex == -1) {
        cout << "Student not found.\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    cout << "\nStudent: " << students[studentIndex].name << " (" << studentId << ")\n";
    cout << "Registered Courses (" << students[studentIndex].courseCount << "):\n";

    if (students[studentIndex].courseCount == 0) {
        cout << "No courses registered.\n";
    }
    else {
        for (int i = 0; i < students[studentIndex].courseCount; i++) {
            int courseCode = students[studentIndex].registeredCourses[i];
            for (int j = 0; j < courseCount; j++) {
                if (courses[j].code == courseCode) {
                    cout << "- " << courses[j].title << " (" << courseCode << ")\n";
                    break;
                }
            }
        }
    }

    cout << "\nPress Enter to continue...";
    cin.ignore(1000, '\n');
    cin.get();
}

void removeRegistration(Registration*& head, Student students[], int studentCount) {
    clearScreen();
    string studentId;
    int courseCode;
    cout << "Enter Student ID: ";
    cin >> studentId;
    cout << "Enter Course Code to remove: ";
    cin >> courseCode;

    int studentIndex = binarySearchStudent(students, studentCount, studentId);

    if (studentIndex == -1) {
        cout << "Student not found.\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    bool foundInStudent = false;
    for (int i = 0; i < students[studentIndex].courseCount; i++) {
        if (students[studentIndex].registeredCourses[i] == courseCode) {
            for (int j = i; j < students[studentIndex].courseCount - 1; j++) {
                students[studentIndex].registeredCourses[j] = students[studentIndex].registeredCourses[j + 1];
            }
            students[studentIndex].courseCount--;
            foundInStudent = true;
            break;
        }
    }

    if (!foundInStudent) {
        cout << "Course registration not found for this student.\n";
        cout << "Press Enter to continue...";
        cin.ignore(1000, '\n');
        cin.get();
        return;
    }

    Registration* current = head;
    Registration* prev = nullptr;

    while (current) {
        if (current->studentId == studentId && current->courseCode == courseCode) {
            if (prev) {
                prev->next = current->next;
            }
            else {
                head = current->next;
            }
            delete current;
            cout << "Registration removed successfully.\n";
            cout << "Press Enter to continue...";
            cin.ignore(1000, '\n');
            cin.get();
            return;
        }
        prev = current;
        current = current->next;
    }

    cout << "Registration not found in system.\n";
    cout << "Press Enter to continue...";
    cin.ignore(1000, '\n');
    cin.get();
}

void cleanup(Registration*& head) {
    while (head) {
        Registration* temp = head;
        head = head->next;
        delete temp;
    }
}

int main() {
    Student students[MAX_STUDENTS];
    Course courses[MAX_COURSES];
    Registration* registrations = nullptr;
    int studentCount = 0;
    int courseCount = 0;

    preloadCourses(courses, courseCount);

    int choice;
    do {
        showMenu();
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        switch (choice) {
        case 1:
            registerStudent(students, studentCount);
            break;
        case 2:
            registerMultipleCourses(registrations, students, studentCount, courses, courseCount);
            break;
        case 3:
            displayRegistrations(registrations, students, studentCount, courses, courseCount);
            break;
        case 4:
            searchStudent(registrations, students, studentCount, courses, courseCount);
            break;
        case 5:
            removeRegistration(registrations, students, studentCount);
            break;
        case 0:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid option. Please try again.\n";
            cout << "Press Enter to continue...";
            cin.ignore(1000, '\n');
        }
    } while (choice != 0);

    cleanup(registrations);
    return 0;
}
